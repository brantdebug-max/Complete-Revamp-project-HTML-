async function geoCurrency(){
  const geo = await fetch('https://ipapi.co/json/').then(r=>r.json());
  const currency = geo.currency || 'USD';
  document.querySelectorAll('.currency').forEach(el=>el.innerText=currency);
}
geoCurrency();
