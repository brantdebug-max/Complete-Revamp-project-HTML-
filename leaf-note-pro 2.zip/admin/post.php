<?php include '../api/db.php';
$title=$_POST['title']; $content=$_POST['content'];
$conn->query("INSERT INTO blog(title,content) VALUES('$title','$content')");
header('Location: index.html');
?>